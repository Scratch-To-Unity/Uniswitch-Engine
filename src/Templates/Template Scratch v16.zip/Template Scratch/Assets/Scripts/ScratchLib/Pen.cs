using UnityEngine;
using Scratch.PenTools;

namespace Scratch
{
    public partial class ScratchSprite  
    {
        [Header("Pen")]
        public float penWidth = 5;
        public Color penColor = Color.blue;
        //[SerializeField]
        //private int screenWidth = 480;
        //[SerializeField]
        //private int screenHeight = 360;
        private PenDrawer pen;
        private bool isPenDown = false;

        /// <summary>
        /// Add a line to the line stack. Deprecated.
        /// </summary>
        private void DrawLine(Vector2 startPosition, Vector2 endPosition)
        {
            //pen.penLines.Add(new PenDrawer.LineData
            //{
            //    startPosition = startPosition,
            //    endPosition = endPosition,
            //    width = penWidth,
            //    color = penColor
            //});
            //pen.currentLine++;
            DrawLineMesh(startPosition, endPosition, penColor, penWidth);
        }

        /// <summary>
        /// <para>Use the Line pool to create line meshes.</para>
        /// </summary>
        public void DrawLineMesh(Vector3 startPosition, Vector3 endPosition, Color color, float width)
        {
            if (pen.currentLine > pen.linePool.childCount - 1)
            {
                Debug.LogWarning("Line pool filled");
                pen.CreateLinePool(10);
                return;
            }
            GameObject lineObject = pen.linePool.GetChild(pen.currentLine).gameObject;
            LineRenderer lineRenderer = lineObject.GetComponent<LineRenderer>();
            MeshFilter meshfilter = lineObject.GetComponent<MeshFilter>();
            //MeshRenderer meshRenderer = lineObject.GetComponent<MeshRenderer>();
            lineObject.SetActive(true);

            pen.currentLine++;

            lineRenderer.SetPosition(0, new Vector3(startPosition.x, startPosition.y, -1));
            lineRenderer.SetPosition(1, new Vector3(endPosition.x, endPosition.y, -1));
            lineObject.transform.position = Vector3.zero;
            lineObject.transform.Translate(0, 0, -pen.currentLayer);

            lineRenderer.startWidth = width;
            lineRenderer.endWidth = width;
            lineRenderer.startColor = color;
            lineRenderer.endColor = color;

            lineRenderer.numCapVertices = Mathf.CeilToInt(width / 4);

            pen.currentLayer++;

            Mesh bakedMesh;
            if (meshfilter.mesh == null)
            {
                bakedMesh = new Mesh();
            }
            else
            {
                bakedMesh = meshfilter.mesh;
                bakedMesh.Clear();
            }
            lineRenderer.BakeMesh(bakedMesh);
            meshfilter.mesh = bakedMesh;
            //meshRenderer.material.color = color;
        }
        /// <summary>
        /// Clear the pen canvas.
        /// </summary>
        public void Clear()
        {
            RenderTexture renderTexture = pen.canvasTexture;
            Graphics.SetRenderTarget(renderTexture);
            GL.Clear(true, true, Color.clear);
            pen.penLines.Clear();
        }
        /// <summary>
        /// The sprite won't draw when moving
        /// </summary>
        public void PenUp()
        {
            isPenDown = false;
        }
        /// <summary>
        /// When moving, the sprite will draw.
        /// </summary>
        public void PenDown()
        {
            isPenDown = true;
            OnMove(transform.position);
        }

        /// <summary>
        /// Stamp the sprite onto the pen canvas.
        /// </summary>
        public void Stamp()
        {
            GameObject stamp = new GameObject("stamp");
            stamp.transform.position = transform.position;
            stamp.transform.rotation = transform.rotation;
            stamp.transform.localScale = transform.localScale;
            SpriteRenderer renderer = stamp.AddComponent<SpriteRenderer>();
            renderer.sprite = spriteRenderer.sprite;
            stamp.layer = 6;
            //stamp.AddComponent<DestroyImmediate>();
            stamp.tag = "Pen_stamp";
            renderer.sortingOrder = pen.currentLayer;
            pen.currentLayer++;
        }
        /// <summary>
        /// Change a color parameter by <paramref name="value"/>.
        /// <para>
        /// The <paramref name="type"/> can be "color", "saturation", "brightness" or "transparency". They correspond to HSVA.
        /// </para>
        /// </summary>
        public void ChangePenColor(float value, ColorParam type)
        {
            value /= 100;
            float H;
            float S;
            float V;
            float A = penColor.a;
            Color.RGBToHSV(penColor, out H, out S, out V);
            switch (type)
            {
                case ColorParam.color:
                    H += value;
                    break;
                case ColorParam.saturation:
                    S += value;
                    break;
                case ColorParam.brightness:
                    V += value;
                    break;
                case ColorParam.transparency:
                    A += value;
                    break;
                default:
                    Debug.LogError("Unknown ColorChange Command");
                    break;
            }
            penColor = Color.HSVToRGB(H, S, V);
            penColor.a = A;
        }
        /// <summary>
        /// Set a color parameter by <paramref name="value"/>.
        /// <para>
        /// The <paramref name="type"/> can be "color", "saturation", "brightness" or "transparency". They correspond to HSVA.
        /// </para>
        /// </summary>
        public void SetPenColor(ColorParam type, float value)
        {
            value /= 100;
            float H;
            float S;
            float V;
            float A = penColor.a;
            Color.RGBToHSV(penColor, out H, out S, out V);
            switch (type)
            {
                case ColorParam.color:
                    H = value;
                    break;
                case ColorParam.saturation:
                    S = value;
                    break;
                case ColorParam.brightness:
                    V = value;
                    break;
                case ColorParam.transparency:
                    A = value;
                    break;
                default:
                    Debug.LogError("Unknown ColorChange Command");
                    break;
            }
            penColor = Color.HSVToRGB(H, S, V);
            penColor.a = A;
        }
        /// <summary>
        /// Converts a hex code to <seealso cref="Color"/>.
        /// </summary>
        public Color HexToColor(string hex)
        {
            Color color;
            if (ColorUtility.TryParseHtmlString(hex, out color))
            {
                return color;
            }
            else
            {
                // Return a default color (e.g., white) if parsing fails
                Debug.LogWarning("Failed to parse hex code: " + hex);
                return Color.white;
            }
        }
        /// <summary>
        /// Scratch color parameter for set and add. Used in <seealso cref="ChangePenColor(float, ColorParam)"/>, and <seealso cref="SetPenColor(ColorParam, float)"/>.
        /// </summary>
        public enum ColorParam
        {
            color,
            saturation,
            brightness,
            transparency
        }
    }
}

