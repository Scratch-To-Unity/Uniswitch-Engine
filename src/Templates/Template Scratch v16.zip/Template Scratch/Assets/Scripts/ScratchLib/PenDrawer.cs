using UnityEngine;
using System.Runtime.InteropServices;
using UnityEngine.UI;
using System.Collections.Generic;
using System;

/// <summary>
/// A class used by <seealso cref="ScratchLib"/> to render pen strokes and stamping.
/// </summary>
namespace Scratch
{
    namespace PenTools
    {
        public class PenDrawer : MonoBehaviour
        {
            [Header("Camera & Textures")]
            public Camera stampCamera;
            public RawImage canvas;
            [NonSerialized]
            public RenderTexture canvasTexture;
            public int textureWidth = 480;
            public int textureHeight = 360;

            [Header("Compute Shader")]
            public List<LineData> penLines = new List<LineData>(2048);
            public ComputeShader lineComputeShader;
            private ComputeBuffer linesBuffer;
            private int kernelIndex;

            [Header("Line mesh")]
            public Transform linePool;
            public GameObject defaultLine;
            public GameObject[] lines;
            public Material lineMaterial;
            public int currentLayer;
            public int currentLine;



            // Define a custom struct to match the LineData struct in the compute shader
            [StructLayout(LayoutKind.Explicit)]
            public struct LineData
            {
                [FieldOffset(0)]
                public Vector2 startPosition;

                [FieldOffset(8)]
                public Vector2 endPosition;

                [FieldOffset(16)]
                public float width;

                [FieldOffset(20)]
                public Color color;
            }

            private void Awake()
            {
                // Create the canvasTexture with the UAV usage flag
                canvasTexture = new RenderTexture(textureWidth, textureHeight, 0, RenderTextureFormat.ARGBFloat);
                canvasTexture.enableRandomWrite = false;
                canvasTexture.wrapMode = TextureWrapMode.Clamp;
                canvasTexture.filterMode = FilterMode.Bilinear;
                canvasTexture.Create();
                canvas.texture = canvasTexture;
                stampCamera.targetTexture = canvasTexture;
                CreateLinePool(1000);
                //linesBuffer = new ComputeBuffer(65535, Marshal.SizeOf(typeof(LineData)));
                /*kernelIndex = lineComputeShader.FindKernel("DrawLines");
                lineComputeShader.SetTexture(kernelIndex, "canvasTexture", canvasTexture);
                lineComputeShader.SetInt("screenWidth", textureWidth);
                lineComputeShader.SetInt("screenHeight", textureHeight);*/
            }

            private void LateUpdate()
            {
                RenderPen();
            }

            private void FixedUpdate()
            {
                //RenderPen();
            }
            /// <summary>
            /// <para>Instantiate a pool of <paramref name="lines"/>.</para>
            /// </summary>
            public void CreateLinePool(int lineNumber)
            {
                for (int i = 0; i < lineNumber; i++)
                {
                    var line = Instantiate(defaultLine, linePool);
                    line.GetComponent<MeshRenderer>().material = new Material(lineMaterial);
                }
                lines = GameObject.FindGameObjectsWithTag("Pen_line");
            }
            /// <summary>
            /// Render all lines in line bufffer using a compute shader
            /// </summary>
            public void RenderPen()
            {
                stampCamera.Render();
                //yield return new WaitForEndOfFrame();
                foreach (GameObject line in lines)
                {
                    //DestroyImmediate(penObject);
                    line.SetActive(false);
                }
                var stamps = GameObject.FindGameObjectsWithTag("Pen_stamp");
                foreach (GameObject stamp in stamps)
                {
                    DestroyImmediate(stamp);
                    //stamp.SetActive(false);
                }
                currentLine = 0;
                currentLayer = 0;

                //stampCamera.Render();
                //if (penLines == null || penLines.Count == 0)
                //{
                //    return;
                //}
                //linesBuffer = new ComputeBuffer(penLines.Count, Marshal.SizeOf(typeof(LineData)));

                //linesBuffer.SetData(penLines);
                //if (linesBuffer == null)
                //{
                //    return;
                //}

                //// Set the render target to the canvas texture.
                //RenderTexture.active = canvasTexture;

                //// Dispatch the compute shader to draw the lines on the canvas texture.

                ////lineComputeShader.SetTexture(kernelIndex, "canvasTexture", canvasTexture);
                ////lineComputeShader.SetInt("screenWidth", textureWidth);
                ////lineComputeShader.SetInt("screenHeight", textureHeight);

                //lineComputeShader.SetBuffer(kernelIndex, "lines", linesBuffer);

                //int groupSize = penLines.Count / 32 + 1;
                //if (groupSize > 65535) { groupSize = 65535; }

                //lineComputeShader.Dispatch(kernelIndex, groupSize, 1, 1);

                //linesBuffer.Release();

                //penLines.Clear();
            }

            // Don't forget to release the texture when the script is destroyed.
            private void OnDestroy()
            {
                if (canvasTexture != null)
                {
                    canvasTexture.Release();
                    canvasTexture = null;
                }
            }
        }
    }
}