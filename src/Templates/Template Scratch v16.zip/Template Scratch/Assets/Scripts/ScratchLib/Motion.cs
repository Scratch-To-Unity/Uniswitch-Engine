using Unity.Burst;
using UnityEngine;

namespace Scratch
{
    public partial class ScratchSprite : MonoBehaviour
    {
        /// <summary>
        /// Called on each move a the sprite.
        /// </summary>
        public void OnMove(Vector2 nextPosition)
        {
            if (!isPenDown)
            {
                return;
            }
            //Vector2 pos1 = transform.position + new Vector3(screenWidth / 2, screenHeight / 2);
            //pos1 = new Vector2(pos1.x / screenWidth, pos1.y / screenHeight);
            //Vector2 pos2 = nextPosition + new Vector2(screenWidth / 2, screenHeight / 2);
            //pos2 = new Vector2(pos2.x / screenWidth, pos2.y / screenHeight);
            DrawLineMesh(transform.position, nextPosition, penColor, penWidth);
        }
        /// <summary>
        /// Move the sprite to (x, y).
        /// </summary>
        //public void GoToXY(object x, object y)
        //{
        //    float valueX = ToFloat(x);
        //    float valueY = ToFloat(y);
        //    OnMove(new Vector2(valueX, valueY));
        //    transform.position = new Vector2(valueX, valueY);
        //}
        public void GoToXY(object x, object y)
        {
            float valueX = ToFloat(x);
            float valueY = ToFloat(y);
            OnMove(new Vector2(valueX, valueY));
            transform.position = new Vector2(valueX, valueY);
        }
        /// <summary>
        /// <para>Move the sprite to another object position. </para>
        /// <paramref name="type"></paramref> can be "mouse", "random" or "sprite". 
        /// In this last case, set <paramref name="name"></paramref> to the sprite's name.
        /// </summary>
        public void GoTo(string type, string name = "")
        {
            switch (type)
            {
                case "mouse":
                    OnMove(GetMousePosition());
                    transform.position = GetMousePosition();
                    break;
                case "random":
                    Vector2 pos = new Vector2(UnityEngine.Random.Range(-240, 240), UnityEngine.Random.Range(-180, 180));
                    OnMove(pos);
                    transform.position = pos;
                    break;
                case "sprite":
                    Transform sprite = GameObject.Find(name).transform;
                    OnMove(sprite.position);
                    transform.position = sprite.position;
                    break;
                default:
                    Debug.LogError("Unknown GoTo Command");
                    break;
            }
        }
        /// <summary>
        /// <para>Turn the sprite towards another object. </para>
        /// <paramref name="type"></paramref> can be "mouse" or "sprite". 
        /// In this last case, set <paramref name="name"></paramref> to the sprite's name.
        /// </summary>
        public void PointTowards(string type, string name = "")
        {
            switch (type)
            {
                case "mouse":
                    transform.rotation = LookAt2D(transform.position, GetMousePosition());
                    break;
                case "sprite":
                    Transform sprite = GameObject.Find(name).transform;
                    transform.rotation = LookAt2D(transform.position, sprite.position);
                    break;
                default:
                    Debug.LogError("Unknown PointTowards Command");
                    break;
            }
        }

        Quaternion LookAt2D(Vector3 position, Vector3 targetPosition)
        {
            Vector3 directionToTarget = targetPosition - position;
            float angle = Mathf.Atan2(directionToTarget.y, directionToTarget.x) * Mathf.Rad2Deg;
            return Quaternion.AngleAxis(angle, Vector3.forward);
        }
        /// <summary>
        /// <para>Change sprite's position along the x axis.</para>
        /// </summary>
        public void ChangeX(object x)
        {
            float value = ToFloat(x);
            OnMove(transform.position + Vector3.right * value);
            transform.Translate(Vector2.right * value, Space.World);
        }
        /// <summary>
        /// <para>Change sprite's position along the y axis.</para>
        /// </summary>
        public void ChangeY(object y)
        {
            float value = ToFloat(y);
            OnMove(transform.position + Vector3.up * value);
            transform.Translate(Vector2.up * value, Space.World);
        }
        /// <summary>
        /// <para>Change sprite's position along its forward axis.</para>
        /// </summary>
        public void MoveSteps(object steps)
        {
            float value = ToFloat(steps);
            Vector2 beforePos = transform.position;
            transform.Translate(Vector2.right * value, Space.Self);
            OnMove(beforePos);
        }
        /// <summary>
        /// <para>Rotate the sprite to the right by <paramref name="degrees"/>.</para>
        /// </summary>
        public void TurnRight(object degrees)
        {
            float value = ToFloat(degrees);
            transform.Rotate(Vector3.forward, value);
        }
        /// <summary>
        /// <para>Rotate the sprite to the left by <paramref name="degrees"/>.</para>
        /// </summary>
        public void TurnLeft(object degrees)
        {
            float value = ToFloat(degrees);
            transform.Rotate(Vector3.forward, -value);
        }
        /// <summary>
        /// <para>Set the sprite's z axis rotation to <paramref name="degrees"/>. </para>
        /// </summary>
        public void SetRotation(object degrees)
        {
            float value = ToFloat(degrees);
            transform.rotation = Quaternion.Euler(Vector3.forward * (value - 90));
        }
        /// <summary>
        /// <para>Set the sprite's x position to <paramref name="x"/>. </para>
        /// </summary>
        public void SetX(object x)
        {
            float value = ToFloat(x);
            OnMove(new Vector2(value, transform.position.y));
            transform.position = new Vector2(value, transform.position.y);
        }
        /// <summary>
        /// <para>Set the sprite's y position to <paramref name="y"/>. </para>
        /// </summary>
        public void SetY(object y)
        {
            float value = ToFloat(y);
            OnMove(new Vector2(transform.position.x, value));
            transform.position = new Vector2(transform.position.x, value);
        }
    }
}
