using UnityEngine;
using System.Collections.Generic;
using System.Reflection;
using System.Collections;
using System;

/// <summary>
/// <para>
/// A class that implements scratch blocks in a human-readable format.
/// </para>
/// <para>
/// It contains various useful functions inspired by scratch's blocks.
/// Use it like this : 
/// </para> 
/// <code>
/// public class MySpriteScript : ScratchLib
/// </code>
/// </summary>
public class ScratchLib : MonoBehaviour
{
    private static List<ScratchLib> spriteScriptInstances = new List<ScratchLib>();

    [Header("Clones")]
    public bool isClone = false;
    private Transform cloneContainer;

    [Header("Collision")]
    [SerializeField]
    public List<GameObject> touchedSprites = new List<GameObject>();
    private GameObject edges;
    private GameObject mouseCollider;

    [Header("Pen")]
    public float penWidth = 5;
    private int penTestSamples;
    public Color penColor = Color.blue;
    private bool isPenDown = false;
    [SerializeField]
    private int screenWidth = 480;
    [SerializeField]
    private int screenHeight = 360;
    private PenDrawer pen;

    [Header("Costumes")]
    [SerializeField]
    private List<Costume> costumes;
    public int currentCostumeIndex;
    public string currentCostumeName;
    public SpriteRenderer spriteRenderer;

    /// <summary>
    /// Initialization of references
    /// </summary>
    private void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        spriteScriptInstances.Add(this);
        pen = FindObjectOfType<PenDrawer>();
        mouseCollider = GameObject.Find("MouseCollider");
        cloneContainer = GameObject.Find("Clone Container").transform;
        if (gameObject.GetComponent<PolygonCollider2D>() == null)
        {
            PolygonCollider2D collider = gameObject.AddComponent<PolygonCollider2D>();
            collider.isTrigger = true;
            Rigidbody2D rb = gameObject.AddComponent<Rigidbody2D>();
            rb.isKinematic = true;
        }
        isClone = transform.parent == cloneContainer;
    }

    #region Pen
    /// <summary>
    /// Add a line to the line stack. Called by OnMove().
    /// </summary>
    private void DrawLine(Vector2 startPosition, Vector2 endPosition)
    {
        pen.penLines.Add(new PenDrawer.LineData
        {
            startPosition = startPosition,
            endPosition = endPosition,
            width = penWidth,
            color = penColor
        });
        //pen.currentLine++;
    }
    /// <summary>
    /// Clear the pen canvas.
    /// </summary>
    public void Clear()
    {
        RenderTexture renderTexture = pen.canvasTexture;
        Graphics.SetRenderTarget(renderTexture);
        GL.Clear(true, true, Color.clear);
        pen.penLines.Clear();
    }
    /// <summary>
    /// The sprite won't draw when moving
    /// </summary>
    public void PenUp()
    {
        isPenDown = false;
    }
    /// <summary>
    /// When moving, the sprite will draw.
    /// </summary>
    public void PenDown()
    {
        isPenDown = true;
        OnMove(transform.position);
    }

    /// <summary>
    /// Stamp the sprite onto the pen canvas.
    /// </summary>
    public void Stamp()
    {
        gameObject.layer = 6;
    }
    /// <summary>
    /// Change a color parameter by <paramref name="value"/>.
    /// <para>
    /// The <paramref name="type"/> can be "color", "saturation", "brightness" or "transparency". They correspond to HSVA.
    /// </para>
    /// </summary>
    public void ChangePenColor(float value, ColorParam type)
    {
        value /= 100;
        float H;
        float S;
        float V;
        float A = penColor.a;
        Color.RGBToHSV(penColor, out H, out S, out V);
        switch (type)
        {
            case ColorParam.color:
                H += value;
                break;
            case ColorParam.saturation:
                S += value;
                break;
            case ColorParam.brightness:
                V += value;
                break;
            case ColorParam.transparency:
                A += value;
                break;
            default:
                Debug.LogError("Unknown ColorChange Command");
                break;
        }
        penColor = Color.HSVToRGB(H, S, V);
        penColor.a = A;
    }
    /// <summary>
    /// Set a color parameter by <paramref name="value"/>.
    /// <para>
    /// The <paramref name="type"/> can be "color", "saturation", "brightness" or "transparency". They correspond to HSVA.
    /// </para>
    /// </summary>
    public void SetPenColor(ColorParam type, float value)
    {
        value /= 100;
        float H;
        float S;
        float V;
        float A = penColor.a;
        Color.RGBToHSV(penColor, out H, out S, out V);
        switch (type)
        {
            case ColorParam.color:
                H = value;
                break;
            case ColorParam.saturation:
                S = value;
                break;
            case ColorParam.brightness:
                V = value;
                break;
            case ColorParam.transparency:
                A = value;
                break;
            default:
                Debug.LogError("Unknown ColorChange Command");
                break;
        }
        penColor = Color.HSVToRGB(H, S, V);
        penColor.a = A;
    }
    /// <summary>
    /// Converts a hex code to <seealso cref="Color"/>.
    /// </summary>
    public Color HexToColor(string hex)
    {
        Color color;
        if (ColorUtility.TryParseHtmlString(hex, out color))
        {
            return color;
        }
        else
        {
            // Return a default color (e.g., white) if parsing fails
            Debug.LogWarning("Failed to parse hex code: " + hex);
            return Color.white;
        }
    }
    /// <summary>
    /// Scratch color parameter for set and add. Used in <seealso cref="ChangePenColor(float, ColorParam)"/>, and <seealso cref="SetPenColor(ColorParam, float)"/>.
    /// </summary>
    public enum ColorParam
    {
        color,
        saturation,
        brightness,
        transparency
    }
    #endregion

    #region Sprites
    /// <summary>
    /// Used for calling messages.
    /// </summary>
    public static List<ScratchLib> GetAllInstances()
    {
        return spriteScriptInstances;
    }
    /// <summary>
    /// Used to track the script instances.
    /// </summary>
    protected virtual void OnDestroy()
    {
        // Remove the instance from the list when it's destroyed
        spriteScriptInstances.Remove(this);
    }
    #endregion


    #region Motions
    /// <summary>
    /// Called on each move a the sprite.
    /// </summary>
    private void OnMove(Vector2 nextPosition)
    {
        if (!isPenDown)
        {
            return;
        }
        Vector2 pos1 = transform.position + new Vector3(screenWidth / 2, screenHeight / 2);
        pos1 = new Vector2(pos1.x / screenWidth, pos1.y / screenHeight);
        Vector2 pos2 = nextPosition + new Vector2(screenWidth / 2, screenHeight / 2);
        pos2 = new Vector2(pos2.x / screenWidth, pos2.y / screenHeight);
        DrawLine(pos1, pos2);
    }
    /// <summary>
    /// Move the sprite to (x, y).
    /// </summary>
    public void GoToXY(object x, object y)
    {
        float valueX = ToFloat(x);
        float valueY = ToFloat(y);
        OnMove(new Vector2(valueX, valueY));
        transform.position = new Vector2(valueX, valueY);
    }
    /// <summary>
    /// <para>Move the sprite to another object position. </para>
    /// <paramref name="type"></paramref> can be "mouse", "random" or "sprite". 
    /// In this last case, set <paramref name="name"></paramref> to the sprite's name.
    /// </summary>
    public void GoTo(string type, string name = "")
    {
        switch (type)
        {
            case "mouse":
                OnMove(GetMousePosition());
                transform.position = GetMousePosition();
                break;
            case "random":
                Vector2 pos = new Vector2(UnityEngine.Random.Range(-240, 240), UnityEngine.Random.Range(-180, 180));
                OnMove(pos);
                transform.position = pos;
                break;
            case "sprite":
                Transform sprite = GameObject.Find(name).transform;
                OnMove(sprite.position);
                transform.position = sprite.position;
                break;
            default:
                Debug.LogError("Unknown GoTo Command");
                break;
        }
    }
    /// <summary>
    /// <para>Turn the sprite towards another object. </para>
    /// <paramref name="type"></paramref> can be "mouse" or "sprite". 
    /// In this last case, set <paramref name="name"></paramref> to the sprite's name.
    /// </summary>
    public void PointTowards(string type, string name = "")
    {
        switch (type)
        {
            case "mouse":
                transform.rotation = LookAt2D(transform.position, GetMousePosition());
                break;
            case "sprite":
                Transform sprite = GameObject.Find(name).transform;
                transform.rotation = LookAt2D(transform.position, sprite.position);
                break;
            default:
                Debug.LogError("Unknown PointTowards Command");
                break;
        }
    }

    Quaternion LookAt2D(Vector3 position, Vector3 targetPosition)
    {
        Vector3 directionToTarget = targetPosition - position;
        float angle = Mathf.Atan2(directionToTarget.y, directionToTarget.x) * Mathf.Rad2Deg;
        return Quaternion.AngleAxis(angle, Vector3.forward);
    }
    /// <summary>
    /// <para>Change sprite's position along the x axis.</para>
    /// </summary>
    public void ChangeX(object x)
    {
        float value = ToFloat(x);
        OnMove(transform.position + Vector3.right * value);
        transform.Translate(Vector2.right * value, Space.World);
    }
    /// <summary>
    /// <para>Change sprite's position along the y axis.</para>
    /// </summary>
    public void ChangeY(object y)
    {
        float value = ToFloat(y);
        OnMove(transform.position + Vector3.up * value);
        transform.Translate(Vector2.up * value, Space.World);
    }
    /// <summary>
    /// <para>Change sprite's position along its forward axis.</para>
    /// </summary>
    public void MoveSteps(object steps)
    {
        float value = ToFloat(steps);
        Vector2 beforePos = transform.position;
        transform.Translate(Vector2.right * value, Space.Self);
        OnMove(beforePos);
    }
    /// <summary>
    /// <para>Rotate the sprite to the right by <paramref name="degrees"/>.</para>
    /// </summary>
    public void TurnRight(object degrees)
    {
        float value = ToFloat(degrees);
        transform.Rotate(Vector3.forward, value);
    }
    /// <summary>
    /// <para>Rotate the sprite to the left by <paramref name="degrees"/>.</para>
    /// </summary>
    public void TurnLeft(object degrees)
    {
        float value = ToFloat(degrees);
        transform.Rotate(Vector3.forward, -value);
    }
    /// <summary>
    /// <para>Set the sprite's z axis rotation to <paramref name="degrees"/>. </para>
    /// </summary>
    public void SetRotation(object degrees)
    {
        float value = ToFloat(degrees);
        transform.rotation = Quaternion.Euler(Vector3.forward * (value - 90));
    }
    /// <summary>
    /// <para>Set the sprite's x position to <paramref name="x"/>. </para>
    /// </summary>
    public void SetX(object x)
    {
        float value = ToFloat(x);
        OnMove(new Vector2(value, transform.position.y));
        transform.position = new Vector2(value, transform.position.y);
    }
    /// <summary>
    /// <para>Set the sprite's y position to <paramref name="y"/>. </para>
    /// </summary>
    public void SetY(object y)
    {
        float value = ToFloat(y);
        OnMove(new Vector2(transform.position.x, value));
        transform.position = new Vector2(transform.position.x, value);
    }

    #endregion

    #region Looks
    /// <summary>
    /// Costume struct used by the sprite.
    /// </summary>
    [System.Serializable]
    public struct Costume
    {
        public string name;
        public Sprite sprite;
        public int index;
    }
    /// <summary>
    /// Sets the costume by its name, or index.
    /// </summary>
    public void SetCostume(object costumeName)
    {
        string costumeNameStr = (string)costumeName;
        char costumeChar = costumeNameStr[0];
        if (char.IsDigit(costumeChar))
        {
            spriteRenderer.sprite = costumes[int.Parse(costumeNameStr) - 1].sprite;
            currentCostumeIndex = int.Parse(costumeNameStr) - 1;
            currentCostumeName = costumes[int.Parse(costumeNameStr) - 1].name;
        }
        else
        {
            Costume costume = costumes.Find(costume => costume.name == (string)costumeName);
            spriteRenderer.sprite = costume.sprite;
            currentCostumeIndex = costume.index;
            currentCostumeName = costume.name;
            if (spriteRenderer.sprite == null)
            {
                spriteRenderer.sprite = costumes[0].sprite;
                currentCostumeIndex = costumes[0].index;
                currentCostumeName = costumes[0].name;
            }
        }
    }
    /// <summary>
    /// Switches to the next costume.
    /// </summary>
    public void NextCostume()
    {
        spriteRenderer.sprite = costumes.Find(costume => costume.index == (currentCostumeIndex + 1) % costumes.Count).sprite;
        currentCostumeIndex += 1;
        currentCostumeIndex %= costumes.Count;
        currentCostumeName = costumes[currentCostumeIndex].name;
    }
    /// <summary>
    /// <para>Disable the sprite renderer.</para>
    /// </summary>
    public void Hide()
    {
        spriteRenderer.enabled = false;
    }
    /// <summary>
    /// <para>Enable the sprite renderer.</para>
    /// </summary>
    public void Show()
    {
        spriteRenderer.enabled = true;
    }
    /// <summary>
    /// <para>Set the scale to <paramref name="size"/>.</para>
    /// </summary>
    public void SetSize(object size)
    {
        float value = ToFloat(size);
        transform.localScale = Vector3.one * value;
    }
    /// <summary>
    /// <para>Change the scale by <paramref name="size"/>.</para>
    /// </summary>
    public void ChangeSize(object size)
    {
        float value = ToFloat(size);
        transform.localScale = transform.localScale - Vector3.one * value;
    }
    /// <summary>
    /// <para>Set the <paramref name="layer"/> of the sprite.</para>
    /// </summary>
    public void SetLayer(string layer)
    {
        spriteRenderer.sortingLayerName = layer;
    }
    /// <summary>
    /// <para>Change the <paramref name="layer"/> of the sprite.</para>
    /// <para>Set the <paramref name="direction"/> to "backward" to substract a layer.</para>
    /// </summary>
    public void ChangeLayer(string direction, int layer)
    {
        if (direction == "backward")
        {
            layer = -layer;
        }
        spriteRenderer.sortingOrder += layer;
    }
    #endregion

    #region Sensing
    /// <summary>
    /// <para>Returns the x position of the mouse.</para>
    /// </summary>
    public float GetMousePositionX()
    {
        return GetMousePosition().x;
    }
    /// <summary>
    /// <para>Returns the y position of the mouse.</para>
    /// </summary>
    public float GetMousePositionY()
    {
        return GetMousePosition().y;
    }

    Vector2 GetMousePosition()
    {
        return Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, 0));
    }

    /// <summary>
    /// Gets the distance to another object. The <paramref name="type"/> can be "mouse" or "sprite".
    /// </summary>
    public float getDistanceTo(string type, string name = "")
    {
        switch (type)
        {
            case "mouse":
                return Vector2.Distance(transform.position, GetMousePosition());
            case "sprite":
                Transform sprite = GameObject.Find(name).transform;
                return Vector2.Distance(transform.position, sprite.position);
            default:
                return 0;
        }
    }
    /// <summary>
    /// Detects if the sprite touches another object. The <paramref name="type"/> can be "mouse", "edge" or "sprite".
    /// </summary>
    public bool Touching(string type, string name = "")
    {
        switch (type)
        {
            case "mouse":
                return touchedSprites.Contains(mouseCollider);
            case "edge":
                return touchedSprites.Contains(edges);
            case "sprite":
                GameObject sprite = GameObject.Find(name);
                return touchedSprites.Contains(sprite);
            default:
                return false;
        }
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        touchedSprites.Add(collision.gameObject);
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        touchedSprites.Remove(collision.gameObject);
    }
    /// <summary>
    /// Translation of scratch's touch key block.
    /// </summary>
    public bool GetKey(string key)
    {
        if (key.Length == 0)
        {
            return false;
        }
        char keyChar = key[0];

        switch (key)
        {
            case "any":
                return Input.anyKey && !Input.GetMouseButton(0);
            case "space":
                return Input.GetKey(KeyCode.Space);
            case "enter":
                return Input.GetKey(KeyCode.Return);
            case "left arrow":
                return Input.GetKey(KeyCode.LeftArrow);
            case "right arrow":
                return Input.GetKey(KeyCode.RightArrow);
            case "up arrow":
                return Input.GetKey(KeyCode.UpArrow);
            case "down arrow":
                return Input.GetKey(KeyCode.DownArrow);
            case "'":
                return Input.GetKey(KeyCode.Quote);
            case ",":
                return Input.GetKey(KeyCode.Comma);
            case ";":
                return Input.GetKey(KeyCode.Semicolon);
            case ":":
                return Input.GetKey(KeyCode.Colon);
            case "!":
                return Input.GetKey(KeyCode.Exclaim);
            case "?":
                return Input.GetKey(KeyCode.Question);
            case ".":
                return Input.GetKey(KeyCode.Period);
            case "/":
                return Input.GetKey(KeyCode.Slash);
            case "~":
                return Input.GetKey(KeyCode.Tilde);
            case "*":
                return Input.GetKey(KeyCode.KeypadMultiply);
            case "-":
                return Input.GetKey(KeyCode.Minus);
            case "(":
                return Input.GetKey(KeyCode.LeftParen);
            case ")":
                return Input.GetKey(KeyCode.RightParen);
            case "+":
                return Input.GetKey(KeyCode.KeypadPlus);
            case "&":
                return Input.GetKey(KeyCode.Ampersand);
            case "_":
                return Input.GetKey(KeyCode.Underscore);
            case "=":
                return Input.GetKey(KeyCode.Equals);
            case "0":
                return Input.GetKey(KeyCode.Keypad0);
            case "1":
                return Input.GetKey(KeyCode.Keypad1);
            case "2":
                return Input.GetKey(KeyCode.Keypad2);
            case "3":
                return Input.GetKey(KeyCode.Keypad3);
            case "4":
                return Input.GetKey(KeyCode.Keypad4);
            case "5":
                return Input.GetKey(KeyCode.Keypad5);
            case "6":
                return Input.GetKey(KeyCode.Keypad6);
            case "7":
                return Input.GetKey(KeyCode.Keypad7);
            case "8":
                return Input.GetKey(KeyCode.Keypad8);
            case "9":
                return Input.GetKey(KeyCode.Keypad9);
            default:
                if (char.IsLetter(keyChar))
                {
                    char uppercaseInput = char.ToUpper(keyChar);
                    KeyCode keyCode = (KeyCode)System.Enum.Parse(typeof(KeyCode), uppercaseInput.ToString());
                    return Input.GetKey(keyCode);
                }
                else
                {
                    Debug.LogError("Unknown key : " + key);
                    return false;
                }
        }
    }
    #endregion

    #region Operators
    /// <summary>
    /// <para>Returns the asked <paramref name="letter"/> without throwing any errors.</para>
    /// </summary>
    public string LetterOf(object letter, object input)
    {
        int idx = ToInt(letter) - 1;
        string value = input.ToString();
        if (idx < 0 || idx > value.Length - 1)
        {
            idx = 0;
        }
        return value[idx].ToString();
    }
    /// <summary>
    /// <para>Try to convert an <paramref name="object"/> to <paramref name="float"/>. Doesn't throw any errors.</para>
    /// </summary>
    public float ToFloat(object inputValue)
    {
        string input = inputValue.ToString();
        if (input == "+Infinity")
        {
            return Mathf.Infinity;
        }
        if (input == "-Infinity")
        {
            return -Mathf.Infinity;
        }
        //try with int.parse first to convert hexadecimals
        float convertedFloat = 0f;
        if (float.TryParse(input, out convertedFloat))
        {
            return convertedFloat;
        }
        else
        {
            print(input);
            try
            {
                return Convert.ToInt32(input, 16);
            }
            catch (Exception)
            {
                Debug.LogError("Couldn't cast to float.");
                return 0f;
            }

        }
    }
    /// <summary>
    /// <para>Try to convert an <paramref name="object"/> to <paramref name="int"/>. Doesn't throw any errors.</para>
    /// </summary>
    public int ToInt(object inputValue)
    {
        try
        {
            return Mathf.RoundToInt((float)inputValue);
        }
        catch (Exception)
        {
            Debug.LogError("Couldn't cast to int.");
            return 0;
        }

    }
    /// <summary>
    /// <para>Returns the asked element of a <paramref name="list"/>. Doesn't throw any errors.</para>
    /// </summary>
    public object ElementOf(List<object> list, float index)
    {
        int idx = Mathf.RoundToInt(index) - 1;
        if (idx < 0 || idx > list.Count - 1)
        {
            print("Index out of range");
            idx = 0;
        }
        return list[idx];
    }
    /// <summary>
    /// <para>Replace the asked element of a <paramref name="list"/> by another <paramref name="value"/>. Doesn't throw any errors.</para>
    /// </summary>
    public void ReplaceItem(List<object> list, float index, object value)
    {
        int idx = Mathf.RoundToInt(index) - 1;
        if (idx < 0 || idx > list.Count - 1)
        {
            print("Index out of range");
            idx = 0;
        }
        list[idx] = value;
    }
    #endregion

    #region Messages
    /// <summary>
    /// Sends a message to all ScratchLib inherited classes.
    /// Set <paramref name="wait"/>  to true to make it synchronous.
    /// </summary>
    public IEnumerator SendMessageToAll(string message, bool wait = false)
    {
        foreach (var sprite in spriteScriptInstances)
        {
            if (CoroutineChecker.ContainsCoroutine(sprite, message))
            {
                if (wait)
                {
                    yield return sprite.StartCoroutine(message);
                }
                else
                {
                    sprite.StartCoroutine(message);
                }

            }
        }
        yield return null;

    }
    #endregion

    #region Clones
    /// <summary>
    /// Duplicate the given GameObject. Set <paramref name="spriteName"/> to "_myself_" to clone this GameObject.
    /// </summary>
    public void CreateClone(string spriteName)
    {
        GameObject sprite;
        if (spriteName == "_myself_")
        {
            sprite = gameObject;
        }
        else
        {
            sprite = GameObject.Find(spriteName);
        }
        Instantiate(sprite, cloneContainer);
    }
    /// <summary>
    /// Delete the GameObject if it's a clone
    /// </summary>
    public void DeleteClone()
    {
        if (isClone)
        {
            Destroy(gameObject);
        }
    }
    #endregion
}

/// <summary>
/// A class used for handling scratch messages.
/// </summary>
public static class CoroutineChecker
{
    public static bool ContainsCoroutine(MonoBehaviour script, string coroutineName)
    {
        foreach (MethodInfo method in script.GetType().GetMethods(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public))
        {
            if (method.ReturnType == typeof(IEnumerator) && method.Name == coroutineName)
            {
                return true;
            }
        }
        return false;
    }
}