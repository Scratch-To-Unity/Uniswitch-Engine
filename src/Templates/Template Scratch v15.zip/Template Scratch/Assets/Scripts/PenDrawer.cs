using UnityEngine;
using System.Runtime.InteropServices;
using UnityEngine.UI;
using System.Collections.Generic;

/// <summary>
/// A class used by <seealso cref="ScratchLib"/> to render pen strokes and stamping.
/// </summary>
public class PenDrawer : MonoBehaviour
{
    public int textureWidth = 480;
    public int textureHeight = 360;

    public Camera stampCamera;
    public ComputeShader lineComputeShader;
    public RawImage canvas;
    public List<LineData> penLines = new List<LineData>(2048);
    public RenderTexture canvasTexture;
    private ComputeBuffer linesBuffer;
    public int currentLine;
    private int kernelIndex;

    // Define a custom struct to match the LineData struct in the compute shader
    [StructLayout(LayoutKind.Explicit)]
    public struct LineData
    {
        [FieldOffset(0)]
        public Vector2 startPosition;

        [FieldOffset(8)]
        public Vector2 endPosition;

        [FieldOffset(16)]
        public float width;

        [FieldOffset(20)]
        public Color color;
    }

    private void Awake()
    {
        // Create the canvasTexture with the UAV usage flag
        canvasTexture = new RenderTexture(textureWidth, textureHeight, 0, RenderTextureFormat.ARGBFloat);
        canvasTexture.enableRandomWrite = true;
        canvasTexture.wrapMode = TextureWrapMode.Clamp;
        canvasTexture.filterMode = FilterMode.Point;
        //canvasTexture.antiAliasing = 4;
        canvasTexture.Create();
        canvas.texture = canvasTexture;
        stampCamera.targetTexture = canvasTexture;
        //linesBuffer = new ComputeBuffer(65535, Marshal.SizeOf(typeof(LineData)));
        kernelIndex = lineComputeShader.FindKernel("DrawLines");
        lineComputeShader.SetTexture(kernelIndex, "canvasTexture", canvasTexture);
        lineComputeShader.SetInt("screenWidth", textureWidth);
        lineComputeShader.SetInt("screenHeight", textureHeight);
    }

    private void LateUpdate()
    {
        RenderPen();
    }

    private void FixedUpdate()
    {
        //RenderPen();
    }
    /// <summary>
    /// Render all lines in line bufffer using a compute shader
    /// </summary>
    public void RenderPen()
    {
        stampCamera.Render();
        if (penLines == null || penLines.Count == 0)
        {
            return;
        }
        linesBuffer = new ComputeBuffer(penLines.Count, Marshal.SizeOf(typeof(LineData)));
        
        linesBuffer.SetData(penLines);
        if (linesBuffer == null)
        {
            return;
        }

        // Set the render target to the canvas texture.
        RenderTexture.active = canvasTexture;

        // Dispatch the compute shader to draw the lines on the canvas texture.

        //lineComputeShader.SetTexture(kernelIndex, "canvasTexture", canvasTexture);
        //lineComputeShader.SetInt("screenWidth", textureWidth);
        //lineComputeShader.SetInt("screenHeight", textureHeight);

        lineComputeShader.SetBuffer(kernelIndex, "lines", linesBuffer);

        int groupSize = penLines.Count / 32 + 1;
        if (groupSize > 65535) { groupSize = 65535; }

        lineComputeShader.Dispatch(kernelIndex, groupSize, 1, 1);

        linesBuffer.Release();

        penLines.Clear();
    }

    // Don't forget to release the texture when the script is destroyed.
    private void OnDestroy()
    {
        if (canvasTexture != null)
        {
            canvasTexture.Release();
            canvasTexture = null;
        }
    }
}