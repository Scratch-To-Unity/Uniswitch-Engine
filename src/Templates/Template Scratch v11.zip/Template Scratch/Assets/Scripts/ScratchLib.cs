using UnityEngine;
using System.Collections.Generic;
using System.Reflection;
using System.Collections;

public class ScratchLib : MonoBehaviour
{
    SpriteRenderer spriteRenderer;
    private static List<ScratchLib> spriteScriptInstances = new List<ScratchLib>();

    public bool isClone = false;

    [Header("Pen")]
    public int penWidth = 5;
    public int penTestSamples;
    public Color penColor = Color.blue;
    public bool isPenDown = false;
    PenDrawer pen;

    [Header("Costumes")]
    [SerializeField]
    public List<Costume> costumes;
    public int currentCostumeIndex;
    public string currentCostumeName;

    [System.Serializable]
    public struct Costume
    {
        public string name;
        public Sprite sprite;
        public int index;
    }

    
    private void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        spriteScriptInstances.Add(this);
        pen = FindObjectOfType<PenDrawer>();
        /*object a = "123";
        object b = "123";
        bool c =((object)a.ToString() == (object)123.ToString());
        print(c);*/
    }

    private void Update()
    {
        //for (int i = 0; i < penTestSamples; i++)
        //{
        //    penWidth = Random.Range(1, 50);
        //    penColor = Random.ColorHSV();
            /*float x = Random.Range(0, 1f);
            float y = Random.Range(0, 1f);
            Vector2 pos = new Vector2(x, y);
            DrawLine(pos, pos + new Vector2(0.01f, 0.01f));*/
        //    DrawLine(new Vector2(Random.Range(0, 1f), Random.Range(0, 1f)), new Vector2(Random.Range(0, 1f), Random.Range(0, 1f)));
        //}
    }

    #region Pen
    void DrawLine(Vector2 startPosition, Vector2 endPosition)
    {
        pen.penLines.Add( new PenDrawer.LineData
        {
            startPosition = startPosition,
            endPosition = endPosition,
            width = penWidth,
            color = penColor
        });
        //pen.currentLine++;
    }

    public void Clear()
    {
        RenderTexture renderTexture = pen.canvasTexture;
        Graphics.SetRenderTarget(renderTexture);
        GL.Clear(true, true, Color.clear);
        pen.penLines.Clear();
    }
    #endregion

    #region sprites
    public static List<ScratchLib> GetAllInstances()
    {
        return spriteScriptInstances;
    }

    protected virtual void OnDestroy()
    {
        // Remove the instance from the list when it's destroyed
        spriteScriptInstances.Remove(this);
    }
    #endregion

    #region Motions

    private void OnMove(Vector2 nextPosition)
    {
        if(!isPenDown)
        {
            return;
        }
        Vector2 pos1 = transform.position + new Vector3(240, 180);
        pos1 /= 480;
        Vector2 pos2 = nextPosition + new Vector2(240, 180);
        pos2 /= 480;
        DrawLine(pos1, pos2);
    }
    public void GoToXY(float x, float y)
    {
        OnMove(new Vector2(x, y));
        transform.position = new Vector2(x, y);
    }
    public void GoTo(string type, string name = "")
    {
        switch (type)
        {
            case "mouse":
                OnMove(GetMousePosition());
                transform.position = GetMousePosition();
                break;
            case "random":
                Vector2 pos = new Vector2(Random.Range(-240, 240), Random.Range(-180, 180));
                OnMove(pos);
                transform.position = pos;
                break;
            case "sprite":
                Transform sprite = GameObject.Find(name).transform;
                OnMove(sprite.position);
                transform.position = sprite.position;
                break;
            default:
                break;
        }
    }
    public void PointTowards(string type, string name = "")
    {
        switch (type)
        {
            case "mouse":
                transform.rotation = LookAt2D(transform.position, GetMousePosition());
                break;
            case "sprite":
                Transform sprite = GameObject.Find(name).transform;
                transform.rotation = LookAt2D(transform.position, sprite.position);
                break;
            default:
                break;
        }
    }

    Quaternion LookAt2D(Vector3 position, Vector3 targetPosition)
    {
        Vector3 directionToTarget = targetPosition - position;
        float angle = Mathf.Atan2(directionToTarget.y, directionToTarget.x) * Mathf.Rad2Deg;
        return Quaternion.AngleAxis(angle, Vector3.forward);
    }
    public void ChangeX(float x)
    {
        OnMove(transform.position + Vector3.right * x);
        transform.Translate(Vector2.right * x);
    }
    public void ChangeY(float y)
    {
        OnMove(transform.position + Vector3.up * y);
        transform.Translate(Vector2.up * y);
    }
    public void MoveSteps(float steps)
    {
        Vector2 beforePos = transform.position;
        transform.Translate(Vector2.right * steps, Space.Self);
        OnMove(beforePos);
    }
    public void TurnRight(float degrees)
    {
        transform.Rotate(Vector3.forward, degrees);
    }
    public void TurnLeft(float degrees)
    {
        transform.Rotate(Vector3.forward, -degrees);
    }
    public void SetRotation(float degrees)
    {
        transform.rotation = Quaternion.Euler(Vector3.forward * (degrees - 90));
    }
    public void SetX(float x)
    {
        OnMove(new Vector2(x, transform.position.y));
        transform.position = new Vector2(x, transform.position.y);
    }
    public void SetY(float y)
    {
        OnMove(new Vector2(transform.position.x, y));
        transform.position = new Vector2(transform.position.x, y);
    }

    #endregion

    #region Looks

    public void SetCostume(object costumeName)
    {
        char costumeChar = char.Parse((string)costumeName);
        if(char.IsDigit(costumeChar))
        {
            spriteRenderer.sprite = costumes[(int)costumeName - 1].sprite;
            currentCostumeIndex = (int)costumeName - 1;
            currentCostumeName = costumes[(int)costumeName - 1].name;
        }
        else
        {
            Costume costume = costumes.Find(costume => costume.name == (string)costumeName);
            spriteRenderer.sprite = costume.sprite;
            currentCostumeIndex = costume.index;
            currentCostumeName = costume.name;
            if (spriteRenderer.sprite == null)
            {
                spriteRenderer.sprite = costumes[0].sprite;
                currentCostumeIndex = costumes[0].index;
                currentCostumeName = costumes[0].name;
            }
        }
    }
    public void NextCostume()
    {
        spriteRenderer.sprite = costumes.Find(costume => costume.index == (currentCostumeIndex + 1) % costumes.Count).sprite;
        currentCostumeIndex += 1;
        currentCostumeIndex %= costumes.Count;
        currentCostumeName = costumes[currentCostumeIndex].name;
    }
    public void Hide()
    {
        GetComponent<SpriteRenderer>().enabled = false;
    }
    public void Show()
    {
        GetComponent<SpriteRenderer>().enabled = true;
    }
    public void SetSize(float size)
    {
        transform.localScale = Vector3.one * size;
    }
    public void ChangeSize(float size)
    {
        transform.localScale = transform.localScale - Vector3.one * size;
    }
    public void SetLayer(string layer)
    {
        spriteRenderer.sortingLayerName = layer;
    }
    public void ChangeLayer(string direction, int layer)
    {
        if (direction == "backward")
        {
            layer = -layer;
        }
        spriteRenderer.sortingOrder += layer;
    }
    #endregion

    #region Sensing
    public float GetMousePositionX()
    {
        return GetMousePosition().x;
    }
    public float GetMousePositionY()
    {
        return GetMousePosition().y;
    }

    Vector2 GetMousePosition()
    {
        return Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, 0));
    }

    public float getDistanceTo(string type, string name = "")
    {
        switch (type)
        {
            case "mouse":
                return Vector2.Distance(transform.position, GetMousePosition());
            case "sprite":
                Transform sprite = GameObject.Find(name).transform;
                return Vector2.Distance(transform.position, sprite.position);
            default:
                return 0;
        }
    }

    public bool GetKey(string key)
    {
        if(key.Length == 0)
        {
            return false;
        }
        char keyChar = char.Parse(key);
        if (char.IsLetter(keyChar))
        {
            char uppercaseInput = char.ToUpper(keyChar);
            KeyCode keyCode = (KeyCode)System.Enum.Parse(typeof(KeyCode), uppercaseInput.ToString());
            return Input.GetKey(keyCode);
        }
        switch (key)
        {
            case "any":
                return Input.anyKey && !Input.GetMouseButton(0);
            case "space":
                return Input.GetKey(KeyCode.Space);
            case "enter":
                return Input.GetKey(KeyCode.Return);
            case "left arrow":
                return Input.GetKey(KeyCode.LeftArrow);
            case "right arrow":
                return Input.GetKey(KeyCode.RightArrow);
            case "up arrow":
                return Input.GetKey(KeyCode.UpArrow);
            case "down arrow":
                return Input.GetKey(KeyCode.DownArrow);
            case "'":
                return Input.GetKey(KeyCode.Quote);
            case ",":
                return Input.GetKey(KeyCode.Comma);
            case ";":
                return Input.GetKey(KeyCode.Semicolon);
            case ":":
                return Input.GetKey(KeyCode.Colon);
            case "!":
                return Input.GetKey(KeyCode.Exclaim);
            case "?":
                return Input.GetKey(KeyCode.Question);
            case ".":
                return Input.GetKey(KeyCode.Period);
            case "/":
                return Input.GetKey(KeyCode.Slash);
            case "~":
                return Input.GetKey(KeyCode.Tilde);
            case "*":
                return Input.GetKey(KeyCode.KeypadMultiply);
            case "-":
                return Input.GetKey(KeyCode.Minus);
            case "(":
                return Input.GetKey(KeyCode.LeftParen);
            case ")":
                return Input.GetKey(KeyCode.RightParen);
            case "+":
                return Input.GetKey(KeyCode.KeypadPlus);
            case "&":
                return Input.GetKey(KeyCode.Ampersand);
            case "_":
                return Input.GetKey(KeyCode.Underscore);
            case "=":
                return Input.GetKey(KeyCode.Equals);
            case "0":
                return Input.GetKey(KeyCode.Keypad0);
            case "1":
                return Input.GetKey(KeyCode.Keypad1);
            case "2":
                return Input.GetKey(KeyCode.Keypad2);
            case "3":
                return Input.GetKey(KeyCode.Keypad3);
            case "4":
                return Input.GetKey(KeyCode.Keypad4);
            case "5":
                return Input.GetKey(KeyCode.Keypad5);
            case "6":
                return Input.GetKey(KeyCode.Keypad6);
            case "7":
                return Input.GetKey(KeyCode.Keypad7);
            case "8":
                return Input.GetKey(KeyCode.Keypad8);
            case "9":
                return Input.GetKey(KeyCode.Keypad9);
            default:
                Debug.LogError("Unknown key : " + key);
                return false;
        }
    }
    #endregion

    #region Operators
    public string LetterOf(int letter, string input)
    {
        return input[letter - 1].ToString();
    }
    #endregion

    #region Messages
    public IEnumerator SendMessageToAll(string message, bool wait = false)
    {
        foreach (var sprite in spriteScriptInstances)
        {
            if (CoroutineChecker.ContainsCoroutine(sprite, message))
            {
                if (wait)
                {
                    yield return sprite.StartCoroutine(message);
                }
                else
                {
                    sprite.StartCoroutine(message);
                }

            }
        }
        yield return null;

    }
    #endregion
}

public static class CoroutineChecker
{
    public static bool ContainsCoroutine(MonoBehaviour script, string coroutineName)
    {
        foreach (MethodInfo method in script.GetType().GetMethods(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public))
        {
            if (method.ReturnType == typeof(IEnumerator) && method.Name == coroutineName)
            {
                return true;
            }
        }
        return false;
    }
}