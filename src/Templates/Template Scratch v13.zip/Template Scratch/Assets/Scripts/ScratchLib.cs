using UnityEngine;
using System.Collections.Generic;
using System.Reflection;
using System.Collections;

/// <summary>
/// <para>
/// A class that implements scratch blocks in a human-readable format.
/// </para>
/// <para>
/// It contains various useful functions inspired by scratch's blocks.
/// Use it like this : 
/// </para> 
/// <code>
/// public class MySpriteScript : ScratchLib
/// </code>
/// </summary>
public class ScratchLib : MonoBehaviour
{
    private static List<ScratchLib> spriteScriptInstances = new List<ScratchLib>();

    [Header("Clones")]
    public bool isClone = false;
    private Transform cloneContainer;

    [Header("Collision")]
    [SerializeField]
    public List<GameObject> touchedSprites = new List<GameObject>();
    private GameObject edges;
    private GameObject mouseCollider;

    [Header("Pen")]
    public int penWidth = 5;
    public int penTestSamples;
    public Color penColor = Color.blue;
    public bool isPenDown = false;
    public int screenWidth = 480;
    public int screenHeight = 360;
    private PenDrawer pen;

    [Header("Costumes")]
    [SerializeField]
    public List<Costume> costumes;
    public int currentCostumeIndex;
    public string currentCostumeName;
    private SpriteRenderer spriteRenderer;

    /// <summary>
    /// Initialization of references
    /// </summary>
    private void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        spriteScriptInstances.Add(this);
        pen = FindObjectOfType<PenDrawer>();
        mouseCollider = GameObject.Find("MouseCollider");
        cloneContainer = GameObject.Find("Clone Container").transform;
        if (gameObject.GetComponent<PolygonCollider2D>() == null)
        {
            PolygonCollider2D collider = gameObject.AddComponent<PolygonCollider2D>();
            collider.isTrigger = true;
            Rigidbody2D rb = gameObject.AddComponent<Rigidbody2D>();
            rb.isKinematic = true;
        }
        isClone = transform.parent == cloneContainer;
    }

    private void Update()
    {
        //for testing purpose
        //for (int i = 0; i < penTestSamples; i++)
        //{
        //    penWidth = Random.Range(1, 50);
        //    penColor = Random.ColorHSV();
        /*float x = Random.Range(0, 1f);
        float y = Random.Range(0, 1f);
        Vector2 pos = new Vector2(x, y);
        DrawLine(pos, pos + new Vector2(0.01f, 0.01f));*/
        //    DrawLine(new Vector2(Random.Range(0, 1f), Random.Range(0, 1f)), new Vector2(Random.Range(0, 1f), Random.Range(0, 1f)));
        //}
    }

    #region Pen
    /// <summary>
    /// Add a line to the line stack. Called by OnMove().
    /// </summary>
    private void DrawLine(Vector2 startPosition, Vector2 endPosition)
    {
        pen.penLines.Add(new PenDrawer.LineData
        {
            startPosition = startPosition,
            endPosition = endPosition,
            width = penWidth,
            color = penColor
        });
        //pen.currentLine++;
    }
    /// <summary>
    /// Clear the pen canvas.
    /// </summary>
    public void Clear()
    {
        RenderTexture renderTexture = pen.canvasTexture;
        Graphics.SetRenderTarget(renderTexture);
        GL.Clear(true, true, Color.clear);
        pen.penLines.Clear();
    }
    /// <summary>
    /// Stamp the sprite onto the pen canvas.
    /// </summary>
    public void Stamp()
    {
        gameObject.layer = 6;
    }
    /// <summary>
    /// Change a color parameter by <paramref name="value"/>.
    /// <para>
    /// The <paramref name="type"/> can be "color", "saturation", "brightness" or "transparency". They correspond to HSVA.
    /// </para>
    /// </summary>
    public void ChangePenColor(float value, ColorParam type)
    {
        value /= 100;
        float H;
        float S;
        float V;
        float A = penColor.a;
        Color.RGBToHSV(penColor, out H, out S, out V);
        switch (type)
        {
            case ColorParam.color:
                H += value;
                break;
            case ColorParam.saturation:
                S += value;
                break;
            case ColorParam.brightness:
                V += value;
                break;
            case ColorParam.transparency:
                A += value;
                break;
            default:
                Debug.LogError("Unknown ColorChange Command");
                break;
        }
        penColor = Color.HSVToRGB(H, S, V);
        penColor.a = A;
    }
    /// <summary>
    /// Set a color parameter by <paramref name="value"/>.
    /// <para>
    /// The <paramref name="type"/> can be "color", "saturation", "brightness" or "transparency". They correspond to HSVA.
    /// </para>
    /// </summary>
    public void SetPenColor(ColorParam type, float value)
    {
        value /= 100;
        float H;
        float S;
        float V;
        float A = penColor.a;
        Color.RGBToHSV(penColor, out H, out S, out V);
        switch (type)
        {
            case ColorParam.color:
                H = value;
                break;
            case ColorParam.saturation:
                S = value;
                break;
            case ColorParam.brightness:
                V = value;
                break;
            case ColorParam.transparency:
                A = value;
                break;
            default:
                Debug.LogError("Unknown ColorChange Command");
                break;
        }
        penColor = Color.HSVToRGB(H, S, V);
        penColor.a = A;
    }
    /// <summary>
    /// Converts a hex code to <seealso cref="Color"/>.
    /// </summary>
    public Color HexToColor(string hex)
    {
        Color color;
        if (ColorUtility.TryParseHtmlString(hex, out color))
        {
            return color;
        }
        else
        {
            // Return a default color (e.g., white) if parsing fails
            Debug.LogWarning("Failed to parse hex code: " + hex);
            return Color.white;
        }
    }
    /// <summary>
    /// Scratch color parameter for set and add. Used in <seealso cref="ChangePenColor(float, ColorParam)"/>, and <seealso cref="SetPenColor(ColorParam, float)"/>.
    /// </summary>
    public enum ColorParam
    {
        color,
        saturation,
        brightness,
        transparency
    }
    #endregion

    #region Sprites
    /// <summary>
    /// Used for calling messages.
    /// </summary>
    public static List<ScratchLib> GetAllInstances()
    {
        return spriteScriptInstances;
    }
    /// <summary>
    /// Used to track the script instances.
    /// </summary>
    protected virtual void OnDestroy()
    {
        // Remove the instance from the list when it's destroyed
        spriteScriptInstances.Remove(this);
    }
    #endregion


    #region Motions
    /// <summary>
    /// Called on each move a the sprite.
    /// </summary>
    private void OnMove(Vector2 nextPosition)
    {
        if (!isPenDown)
        {
            return;
        }
        Vector2 pos1 = transform.position + new Vector3(screenWidth / 2, screenHeight / 2);
        pos1 /= screenWidth;
        Vector2 pos2 = nextPosition + new Vector2(screenWidth / 2, screenHeight / 2);
        pos2 /= screenWidth;
        DrawLine(pos1, pos2);
    }
    public void GoToXY(float x, float y)
    {
        OnMove(new Vector2(x, y));
        transform.position = new Vector2(x, y);
    }
    public void GoTo(string type, string name = "")
    {
        switch (type)
        {
            case "mouse":
                OnMove(GetMousePosition());
                transform.position = GetMousePosition();
                break;
            case "random":
                Vector2 pos = new Vector2(UnityEngine.Random.Range(-240, 240), UnityEngine.Random.Range(-180, 180));
                OnMove(pos);
                transform.position = pos;
                break;
            case "sprite":
                Transform sprite = GameObject.Find(name).transform;
                OnMove(sprite.position);
                transform.position = sprite.position;
                break;
            default:
                Debug.LogError("Unknown GoTo Command");
                break;
        }
    }
    public void PointTowards(string type, string name = "")
    {
        switch (type)
        {
            case "mouse":
                transform.rotation = LookAt2D(transform.position, GetMousePosition());
                break;
            case "sprite":
                Transform sprite = GameObject.Find(name).transform;
                transform.rotation = LookAt2D(transform.position, sprite.position);
                break;
            default:
                Debug.LogError("Unknown PointTowards Command");
                break;
        }
    }

    Quaternion LookAt2D(Vector3 position, Vector3 targetPosition)
    {
        Vector3 directionToTarget = targetPosition - position;
        float angle = Mathf.Atan2(directionToTarget.y, directionToTarget.x) * Mathf.Rad2Deg;
        return Quaternion.AngleAxis(angle, Vector3.forward);
    }
    public void ChangeX(float x)
    {
        OnMove(transform.position + Vector3.right * x);
        transform.Translate(Vector2.right * x, Space.World);
    }
    public void ChangeY(float y)
    {
        OnMove(transform.position + Vector3.up * y);
        transform.Translate(Vector2.up * y, Space.World);
    }
    public void MoveSteps(float steps)
    {
        Vector2 beforePos = transform.position;
        transform.Translate(Vector2.right * steps, Space.Self);
        OnMove(beforePos);
    }
    public void TurnRight(float degrees)
    {
        transform.Rotate(Vector3.forward, degrees);
    }
    public void TurnLeft(float degrees)
    {
        transform.Rotate(Vector3.forward, -degrees);
    }
    public void SetRotation(float degrees)
    {
        transform.rotation = Quaternion.Euler(Vector3.forward * (degrees - 90));
    }
    public void SetX(float x)
    {
        OnMove(new Vector2(x, transform.position.y));
        transform.position = new Vector2(x, transform.position.y);
    }
    public void SetY(float y)
    {
        OnMove(new Vector2(transform.position.x, y));
        transform.position = new Vector2(transform.position.x, y);
    }

    #endregion

    #region Looks
    /// <summary>
    /// Costume struct used by the sprite.
    /// </summary>
    [System.Serializable]
    public struct Costume
    {
        public string name;
        public Sprite sprite;
        public int index;
    }
    /// <summary>
    /// Sets the costume by its name, or index.
    /// </summary>
    public void SetCostume(object costumeName)
    {
        string costumeNameStr = (string)costumeName;
        char costumeChar = costumeNameStr[0];
        if (char.IsDigit(costumeChar))
        {
            spriteRenderer.sprite = costumes[int.Parse(costumeNameStr) - 1].sprite;
            currentCostumeIndex = int.Parse(costumeNameStr) - 1;
            currentCostumeName = costumes[int.Parse(costumeNameStr) - 1].name;
        }
        else
        {
            Costume costume = costumes.Find(costume => costume.name == (string)costumeName);
            spriteRenderer.sprite = costume.sprite;
            currentCostumeIndex = costume.index;
            currentCostumeName = costume.name;
            if (spriteRenderer.sprite == null)
            {
                spriteRenderer.sprite = costumes[0].sprite;
                currentCostumeIndex = costumes[0].index;
                currentCostumeName = costumes[0].name;
            }
        }
    }
    /// <summary>
    /// Switches to the next costume.
    /// </summary>
    public void NextCostume()
    {
        spriteRenderer.sprite = costumes.Find(costume => costume.index == (currentCostumeIndex + 1) % costumes.Count).sprite;
        currentCostumeIndex += 1;
        currentCostumeIndex %= costumes.Count;
        currentCostumeName = costumes[currentCostumeIndex].name;
    }
    public void Hide()
    {
        GetComponent<SpriteRenderer>().enabled = false;
    }
    public void Show()
    {
        GetComponent<SpriteRenderer>().enabled = true;
    }
    public void SetSize(float size)
    {
        transform.localScale = Vector3.one * size;
    }
    public void ChangeSize(float size)
    {
        transform.localScale = transform.localScale - Vector3.one * size;
    }
    public void SetLayer(string layer)
    {
        spriteRenderer.sortingLayerName = layer;
    }
    public void ChangeLayer(string direction, int layer)
    {
        if (direction == "backward")
        {
            layer = -layer;
        }
        spriteRenderer.sortingOrder += layer;
    }
    #endregion

    #region Sensing
    public float GetMousePositionX()
    {
        return GetMousePosition().x;
    }
    public float GetMousePositionY()
    {
        return GetMousePosition().y;
    }

    Vector2 GetMousePosition()
    {
        return Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, 0));
    }

    /// <summary>
    /// Gets the distance to another object. The <paramref name="type"/> can be "mouse" or "sprite".
    /// </summary>
    public float getDistanceTo(string type, string name = "")
    {
        switch (type)
        {
            case "mouse":
                return Vector2.Distance(transform.position, GetMousePosition());
            case "sprite":
                Transform sprite = GameObject.Find(name).transform;
                return Vector2.Distance(transform.position, sprite.position);
            default:
                return 0;
        }
    }
    /// <summary>
    /// Detects if the sprite touches another object. The <paramref name="type"/> can be "mouse", "edge" or "sprite".
    /// </summary>
    public bool Touching(string type, string name = "")
    {
        switch (type)
        {
            case "mouse":
                return touchedSprites.Contains(mouseCollider);
            case "edge":
                return touchedSprites.Contains(edges);
            case "sprite":
                GameObject sprite = GameObject.Find(name);
                return touchedSprites.Contains(sprite);
            default:
                return false;
        }
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        touchedSprites.Add(collision.gameObject);
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        touchedSprites.Remove(collision.gameObject);
    }
    /// <summary>
    /// Translation of scratch's touch key block.
    /// </summary>
    public bool GetKey(string key)
    {
        if (key.Length == 0)
        {
            return false;
        }
        char keyChar = key[0];

        switch (key)
        {
            case "any":
                return Input.anyKey && !Input.GetMouseButton(0);
            case "space":
                return Input.GetKey(KeyCode.Space);
            case "enter":
                return Input.GetKey(KeyCode.Return);
            case "left arrow":
                return Input.GetKey(KeyCode.LeftArrow);
            case "right arrow":
                return Input.GetKey(KeyCode.RightArrow);
            case "up arrow":
                return Input.GetKey(KeyCode.UpArrow);
            case "down arrow":
                return Input.GetKey(KeyCode.DownArrow);
            case "'":
                return Input.GetKey(KeyCode.Quote);
            case ",":
                return Input.GetKey(KeyCode.Comma);
            case ";":
                return Input.GetKey(KeyCode.Semicolon);
            case ":":
                return Input.GetKey(KeyCode.Colon);
            case "!":
                return Input.GetKey(KeyCode.Exclaim);
            case "?":
                return Input.GetKey(KeyCode.Question);
            case ".":
                return Input.GetKey(KeyCode.Period);
            case "/":
                return Input.GetKey(KeyCode.Slash);
            case "~":
                return Input.GetKey(KeyCode.Tilde);
            case "*":
                return Input.GetKey(KeyCode.KeypadMultiply);
            case "-":
                return Input.GetKey(KeyCode.Minus);
            case "(":
                return Input.GetKey(KeyCode.LeftParen);
            case ")":
                return Input.GetKey(KeyCode.RightParen);
            case "+":
                return Input.GetKey(KeyCode.KeypadPlus);
            case "&":
                return Input.GetKey(KeyCode.Ampersand);
            case "_":
                return Input.GetKey(KeyCode.Underscore);
            case "=":
                return Input.GetKey(KeyCode.Equals);
            case "0":
                return Input.GetKey(KeyCode.Keypad0);
            case "1":
                return Input.GetKey(KeyCode.Keypad1);
            case "2":
                return Input.GetKey(KeyCode.Keypad2);
            case "3":
                return Input.GetKey(KeyCode.Keypad3);
            case "4":
                return Input.GetKey(KeyCode.Keypad4);
            case "5":
                return Input.GetKey(KeyCode.Keypad5);
            case "6":
                return Input.GetKey(KeyCode.Keypad6);
            case "7":
                return Input.GetKey(KeyCode.Keypad7);
            case "8":
                return Input.GetKey(KeyCode.Keypad8);
            case "9":
                return Input.GetKey(KeyCode.Keypad9);
            default:
                if (char.IsLetter(keyChar))
                {
                    char uppercaseInput = char.ToUpper(keyChar);
                    KeyCode keyCode = (KeyCode)System.Enum.Parse(typeof(KeyCode), uppercaseInput.ToString());
                    return Input.GetKey(keyCode);
                }
                else
                {
                    Debug.LogError("Unknown key : " + key);
                    return false;
                }
        }
    }
    #endregion

    #region Operators
    public string LetterOf(float letter, string input)
    {
        return input[Mathf.RoundToInt(letter) - 1].ToString();
    }
    #endregion

    #region Messages
    /// <summary>
    /// Sends a message to all ScratchLib inherited classes.
    /// Set <paramref name="wait"/>  to true to make it synchronous.
    /// </summary>
    public IEnumerator SendMessageToAll(string message, bool wait = false)
    {
        foreach (var sprite in spriteScriptInstances)
        {
            if (CoroutineChecker.ContainsCoroutine(sprite, message))
            {
                if (wait)
                {
                    yield return sprite.StartCoroutine(message);
                }
                else
                {
                    sprite.StartCoroutine(message);
                }

            }
        }
        yield return null;

    }
    #endregion

    #region Clones
    /// <summary>
    /// Duplicate the given GameObject. Set <paramref name="spriteName"/> to "_myself_" to clone this GameObject.
    /// </summary>
    public void CreateClone(string spriteName)
    {
        GameObject sprite;
        if(spriteName == "_myself_")
        {
            sprite = gameObject;
        }
        else
        {
            sprite = GameObject.Find(spriteName);
        }
        Instantiate(sprite, cloneContainer);
    }
    /// <summary>
    /// Delete the GameObject if it's a clone
    /// </summary>
    public void DeleteClone()
    {
        if (isClone)
        {
            Destroy(gameObject);
        }
    }
    #endregion
}

/// <summary>
/// A class used for handling scratch messages.
/// </summary>
public static class CoroutineChecker
{
    public static bool ContainsCoroutine(MonoBehaviour script, string coroutineName)
    {
        foreach (MethodInfo method in script.GetType().GetMethods(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public))
        {
            if (method.ReturnType == typeof(IEnumerator) && method.Name == coroutineName)
            {
                return true;
            }
        }
        return false;
    }
}