using UnityEngine;
using System.Runtime.InteropServices;
using UnityEngine.UI;
using System.Collections.Generic;

public class PenDrawer : MonoBehaviour
{
    public int textureWidth = 480;
    public int textureHeight = 360;
    public ComputeShader lineComputeShader;
    public RawImage canvas;
    public List<LineData> penLines = new List<LineData>(2048);
    //public LineData[] penLines = new LineData[1048576];
    public int currentLine;

    public RenderTexture canvasTexture;
    private ComputeBuffer linesBuffer;

    // Define a custom struct to match the LineData struct in the compute shader
    [StructLayout(LayoutKind.Explicit)]
    public struct LineData
    {
        [FieldOffset(0)]
        public Vector2 startPosition;

        [FieldOffset(8)]
        public Vector2 endPosition;

        [FieldOffset(16)]
        public float width;

        [FieldOffset(20)]
        public Color color;
    }

    private void Awake()
    {
        // Create the canvasTexture with the UAV usage flag
        canvasTexture = new RenderTexture(textureWidth, textureHeight, 0, RenderTextureFormat.ARGBFloat);
        canvasTexture.enableRandomWrite = true;
        canvasTexture.wrapMode = TextureWrapMode.Clamp;
        canvasTexture.filterMode = FilterMode.Bilinear;
        //canvasTexture.antiAliasing = 4;
        canvasTexture.Create();
        canvas.texture = canvasTexture;
    }

    private void LateUpdate()
    {
        /*LineData[] linesData = new LineData[]
        {
            new LineData
            {
                startPosition = new Vector2(0.2f, 0.1f),
                endPosition = new Vector2(0.8f, 0.5f),
                width = 20,
                color = Color.red
            },
            new LineData
            {
                startPosition = new Vector2(0.7f, 0.4f),
                endPosition = new Vector2(0.3f, 0.8f),
                width = 10,
                color = Color.blue
            }
        };*/
        if (penLines == null || penLines.Count == 0)
        {
            return;
        }

        linesBuffer = new ComputeBuffer(penLines.Count, Marshal.SizeOf(typeof(LineData)));
        linesBuffer.SetData(penLines);
        if (linesBuffer == null)
        {
            return;
        }

        // Set the render target to the canvas texture.
        RenderTexture.active = canvasTexture;

        // Dispatch the compute shader to draw the lines on the canvas texture.
        int kernel = lineComputeShader.FindKernel("DrawLines");

        lineComputeShader.SetTexture(kernel, "canvasTexture", canvasTexture);
        lineComputeShader.SetInt("screenWidth", textureWidth);
        lineComputeShader.SetInt("screenHeight", textureHeight);

        lineComputeShader.SetBuffer(kernel, "lines", linesBuffer);

        int groupSize = penLines.Count / 32 + 1;
        if(groupSize > 65535) { groupSize = 65535; }

        lineComputeShader.Dispatch(kernel, groupSize, 1, 1);
        //500,000/s at "/1"
        // at "/4"

        linesBuffer.Release();

        penLines.Clear();
    }

    // Don't forget to release the texture when the script is destroyed.
    private void OnDestroy()
    {
        if (canvasTexture != null)
        {
            canvasTexture.Release();
            canvasTexture = null;
        }
    }
}