using UnityEngine;

public class ScratchLib : MonoBehaviour
{
    #region Motions
    public void GoTo(float x, float y)
    {
        transform.position = new Vector2(x, y);
    }
    public void ChangeX(float x)
    {
        transform.Translate(Vector2.right * x);
    }
    public void ChangeY(float y)
    {
        transform.Translate(Vector2.up * y);
    }
    public void MoveSteps(float steps)
    {
        transform.Translate(Vector2.right * steps, Space.Self);
    }
    public void TurnRight(float degrees)
    {
        transform.Rotate(Vector3.forward, degrees);
    }
    public void TurnLeft(float degrees)
    {
        transform.Rotate(Vector3.forward, -degrees);
    }
    public void SetRotation(float degrees)
    {
        transform.rotation = Quaternion.Euler(Vector3.forward * (degrees - 90));
    }
    public void SetX(float x)
    {
        transform.position = new Vector2(x, transform.position.y);
    }
    public void SetY(float y)
    {
        transform.position = new Vector2(transform.position.x, y);
    }

    #endregion

    #region Looks
    public void Hide()
    {
        GetComponent<SpriteRenderer>().enabled = false;
    }
    public void Show()
    {
        GetComponent<SpriteRenderer>().enabled = true;
    }
    public void SetSize(float size)
    {
        transform.localScale = Vector3.one * size;
    }
    public void ChangeSize(float size)
    {
        transform.localScale = transform.localScale - Vector3.one * size;
        
    }
    #endregion
}