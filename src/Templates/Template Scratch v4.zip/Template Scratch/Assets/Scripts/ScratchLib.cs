using UnityEngine;

public class ScratchLib : MonoBehaviour
{
    public void GoTo(float x, float y)
    {
        transform.position = new Vector2(pU(x), pU(y));
    }

    //pixel to unit
    public float pU(float pixel)
    {
        return pixel / 60;
    }

    //unit to pixel
    public float uP(float unit)
    {
        return unit * 60;
    }

    public void ChangeX(float x)
    {
        transform.Translate(Vector2.right * pU(x));
    }
    public void ChangeY(float y)
    {
        transform.Translate(Vector2.up * pU(y));
    }
}
