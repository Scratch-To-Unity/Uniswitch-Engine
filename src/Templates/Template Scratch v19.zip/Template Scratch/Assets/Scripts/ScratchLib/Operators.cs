using System.Collections.Generic;
using UnityEngine;

namespace Scratch
{
    public partial class ScratchSprite : MonoBehaviour
    {
        /// <summary>
        /// <para>Returns the asked <paramref name="letter"/> without throwing any errors.</para>
        /// </summary>
        public string LetterOf(object letter, object input)
        {
            int idx = ToInt(letter) - 1;
            string value = input.ToString();
            if (idx < 0 || idx > value.Length - 1)
            {
                idx = 0;
            }
            return value[idx].ToString();
        }
        /// <summary>
        /// <para>Returns the asked element of a <paramref name="list"/>. Doesn't throw any errors.</para>
        /// </summary>
        public object ElementOf(List<object> list, float index)
        {
            int idx = Mathf.RoundToInt(index) - 1;
            if (idx < 0 || idx > list.Count - 1)
            {
                print("Index out of range");
                idx = 0;
            }
            return list[idx];
        }
        /// <summary>
        /// <para>Replace the asked element of a <paramref name="list"/> by another <paramref name="value"/>. Doesn't throw any errors.</para>
        /// </summary>
        public void ReplaceItem(List<object> list, float index, object value)
        {
            int idx = Mathf.RoundToInt(index) - 1;
            if (idx < 0 || idx > list.Count - 1)
            {
                print("Index out of range");
                idx = 0;
            }
            list[idx] = value;
        }
        /// <summary>
        /// Insert a <paramref name="value"/> at <paramref name="index"/> in a scratch <paramref name="list"/>.
        /// </summary>
        public void Insert(List<object> list, object value, object index)
        {
            list.Insert(Mathf.Clamp(ToInt(index) - 1, 0, list.Count - 1), value);
        }

    }
}
