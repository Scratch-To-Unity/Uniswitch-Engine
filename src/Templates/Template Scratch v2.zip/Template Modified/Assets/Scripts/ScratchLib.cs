using UnityEngine;

public class ScratchLib : MonoBehaviour
{
    float pixelToUnit(float pixel)
    {
        return pixel / 60;
    }

    float UnitToPixel(float unit)
    {
        return unit * 60;
    }
}
