using UnityEngine;
using System.Collections;

public class ScratchLib : MonoBehaviour
{
    #region Adapter
    //pixel to unit
    public float pU(float pixel)
    {
        return pixel / 60;
    }

    //unit to pixel
    public float uP(float unit)
    {
        return unit * 60;
    }
    #endregion

    #region Motions
    public void GoTo(float x, float y)
    {
        transform.position = new Vector2(pU(x), pU(y));
    }
    public void ChangeX(float x)
    {
        transform.Translate(Vector2.right * pU(x));
    }
    public void ChangeY(float y)
    {
        transform.Translate(Vector2.up * pU(y));
    }
    public void MoveSteps(float steps)
    {
        transform.Translate(Vector2.right * pU(steps), Space.Self);
    }
    public void TurnRight(float degrees)
    {
        transform.Rotate(Vector3.forward, degrees);
    }
    public void TurnLeft(float degrees)
    {
        transform.Rotate(Vector3.forward, -degrees);
    }
    public void SetRotation(float degrees)
    {
        transform.rotation = Quaternion.Euler(Vector3.forward * (degrees - 90));
    }
    public void SetX(float x)
    {
        transform.position = new Vector2(pU(x), transform.position.y);
    }
    public void SetY(float y)
    {
        transform.position = new Vector2(transform.position.x, pU(y));
    }

    #endregion

    #region Looks
    public void Hide()
    {
        GetComponent<SpriteRenderer>().enabled = false;
    }
    public void Show()
    {
        GetComponent<SpriteRenderer>().enabled = true;
    }
    public void SetSize(float size)
    {
        transform.localScale = Vector3.one * (size / 100);
    }
    public void ChangeSize(float size)
    {
        transform.localScale = transform.localScale - Vector3.one * (size / 100);
        
    }
    #endregion
}
