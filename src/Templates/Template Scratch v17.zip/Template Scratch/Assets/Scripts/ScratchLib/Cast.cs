using System;
using UnityEngine;

namespace Scratch
{
    public partial class ScratchSprite
    {
        /// <summary>
        /// <para>Try to convert an <paramref name="object"/> to <paramref name="float"/>. Doesn't throw any errors.</para>
        /// </summary>
        //[BurstCompile]
        public static float ToFloat(object inputValue)
        {
            try
            {
                return (float)inputValue;
            }
            catch (Exception)
            {
                string input = inputValue.ToString();

                //try with int.parse first to convert hexadecimals

                float convertedFloat = 0f;
                if (float.TryParse(input, out convertedFloat))
                {
                    return convertedFloat;
                }
                else
                {
                    return ToFloat(input);
                }
            }
        }

        /// <summary>
        /// <para>Try to convert a <paramref name="string"/> to <paramref name="float"/>. Doesn't throw any errors.</para>
        /// </summary>
        public static float ToFloat(string inputValue)
        {
            try
            {
                return Convert.ToInt32(inputValue, 16);
            }
            catch (Exception)
            {
                switch (inputValue)
                {
                    case "+Infinity":
                        return Mathf.Infinity;
                    case "-Infinity":
                        return -Mathf.Infinity;
                    case "True":
                        return 1f;
                    case "False":
                        return 0f;
                    default:
                        break;
                }
                Debug.LogError("Couldn't cast to float.");
                return 0f;
            }
        }
        /// <summary>
        /// <para>Returns the <paramref name="inputValue"/>.</para>
        /// </summary>
        public static float ToFloat(float inputValue)
        {
            return inputValue;
        }
        /// <summary>
        /// <para>Returns the <paramref name="inputValue"/> casted to float.</para>
        /// </summary>
        public static float ToFloat(int inputValue)
        {
            return inputValue;
        }
        /// <summary>
        /// <para>Try to convert an <paramref name="object"/> to <paramref name="int"/>. Doesn't throw any errors.</para>
        /// </summary>
        public static int ToInt(object inputValue)
        {
            try
            {
                return Mathf.RoundToInt((float)inputValue);
            }
            catch (Exception)
            {
                Debug.LogError("Couldn't cast to int.");
                return 0;
            }
        }
        /// <summary>
        /// <para>Try to convert a <paramref name="string"/> to <paramref name="int"/>. Doesn't throw any errors.</para>
        /// </summary>
        public static int ToInt(string inputValue)
        {
            try
            {
                return Mathf.RoundToInt(Convert.ToInt32(inputValue));
            }
            catch (Exception)
            {
                Debug.LogError("Couldn't cast to int.");
                throw;
            }
        }
        /// <summary>
        /// <para>Returns the <paramref name="inputValue"/>.</para>
        /// </summary>
        public static int ToInt(int inputValue)
        {
            return inputValue;
        }
        /// <summary>
        /// <para>Round the <paramref name="float"/> to <paramref name="int"/>.</para>
        /// </summary>
        public static int ToInt(float inputValue)
        {
            return Mathf.RoundToInt(inputValue);
        }
    }
}
