using System.Collections.Generic;
using UnityEngine;
using Scratch.PenTools;

namespace Scratch
{
    /// <summary>
    /// <para>
    /// A class that implements scratch blocks in a human-readable format.
    /// </para>
    /// <para>
    /// It contains various useful functions inspired by scratch's blocks.
    /// Use it like this : 
    /// </para> 
    /// <code>
    /// public class MySpriteScript : ScratchSprite
    /// </code>
    /// </summary>
    public partial class ScratchSprite : MonoBehaviour
    {
        private static List<ScratchSprite> spriteScriptInstances = new List<ScratchSprite>();

        [Header("Clones")]
        public bool isClone = false;
        private Transform cloneContainer;

        [Header("Collision")]
        [SerializeField]
        public List<GameObject> touchedSprites = new List<GameObject>();
        private GameObject edges;
        private GameObject mouseCollider;

        /// <summary>
        /// Initialization of references
        /// </summary>
        private void Awake()
        {
            spriteRenderer = GetComponent<SpriteRenderer>();
            spriteScriptInstances.Add(this);
            pen = FindObjectOfType<PenDrawer>();
            mouseCollider = GameObject.Find("MouseCollider");
            cloneContainer = GameObject.Find("Clone Container").transform;
            if (gameObject.GetComponent<PolygonCollider2D>() == null)
            {
                PolygonCollider2D collider = gameObject.AddComponent<PolygonCollider2D>();
                collider.isTrigger = true;
                Rigidbody2D rb = gameObject.AddComponent<Rigidbody2D>();
                rb.isKinematic = true;
            }
            isClone = transform.parent == cloneContainer;
        }

        /// <summary>
        /// Used to track the script instances.
        /// </summary>
        protected virtual void OnDestroy()
        {
            // Remove the instance from the list when it's destroyed
            spriteScriptInstances.Remove(this);
        }

        #region Operators
        /// <summary>
        /// <para>Returns the asked <paramref name="letter"/> without throwing any errors.</para>
        /// </summary>
        public string LetterOf(object letter, object input)
        {
            int idx = ToInt(letter) - 1;
            string value = input.ToString();
            if (idx < 0 || idx > value.Length - 1)
            {
                idx = 0;
            }
            return value[idx].ToString();
        }
        /// <summary>
        /// <para>Returns the asked element of a <paramref name="list"/>. Doesn't throw any errors.</para>
        /// </summary>
        public object ElementOf(List<object> list, float index)
        {
            int idx = Mathf.RoundToInt(index) - 1;
            if (idx < 0 || idx > list.Count - 1)
            {
                print("Index out of range");
                idx = 0;
            }
            return list[idx];
        }
        /// <summary>
        /// <para>Replace the asked element of a <paramref name="list"/> by another <paramref name="value"/>. Doesn't throw any errors.</para>
        /// </summary>
        public void ReplaceItem(List<object> list, float index, object value)
        {
            int idx = Mathf.RoundToInt(index) - 1;
            if (idx < 0 || idx > list.Count - 1)
            {
                print("Index out of range");
                idx = 0;
            }
            list[idx] = value;
        }
        #endregion

        #region Clones
        /// <summary>
        /// Duplicate the given GameObject. Set <paramref name="spriteName"/> to "_myself_" to clone this GameObject.
        /// </summary>
        public void CreateClone(string spriteName)
        {
            GameObject sprite;
            if (spriteName == "_myself_")
            {
                sprite = gameObject;
            }
            else
            {
                sprite = GameObject.Find(spriteName);
            }
            Instantiate(sprite, cloneContainer);
        }
        /// <summary>
        /// Delete the GameObject if it's a clone
        /// </summary>
        public void DeleteClone()
        {
            if (isClone)
            {
                Destroy(gameObject);
            }
        }
        #endregion
    }

    public enum Target
    {
        sprite,
        mouse,
        random,
        edge,
        stage
    }
}